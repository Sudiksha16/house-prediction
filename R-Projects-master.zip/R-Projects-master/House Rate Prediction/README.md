# House Pricing Production

The dataset used was Boston House Pricing which is maintained at Carnegie Mellon University and is freely available for download from the UCI Machine Learning Repository. The dataset consists of 506 observations of 14 attributes.

## Appraoch

Two methods were used -  
1.Linear Regression Model  
2.Random Forest Model

## Conclusion

The random forest model proved to be better with least Root mean squared error (RMSE).
