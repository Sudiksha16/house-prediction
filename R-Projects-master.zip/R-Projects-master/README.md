# Multiple Mini Projects in R

The repository currently contains -  
1.House Rate Prediction  
2.Customer Segmentation - K means clutering

## Getting Started

```
git clone
Open with R studio
```

### Prerequisites

```
You'll require the latest verion of R and R studio.
```

### Installing

## License

Copyright © 2020, Anushka Paradkar
